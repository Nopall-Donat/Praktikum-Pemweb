<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengantar extends CI_Controller {

    public function index() {
        $data['judul'] = 'Dashboard Praktikum 02';
        $data['title'] = 'Praktikum 2';
		$this->load->view('praktikum/praktikum_2/pengantar/index', $data);

    }

}
?>