<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form_belanja extends CI_Controller {

    public function index() {

        // $_costumer = $_POST['customer'];
        // $_barang = $_POST['produk'];
        // $_jumlah = $_POST['jumlah'];

        $customer = $this->input->post('customer');
        $barang = $this->input->post('produk');
        $jumlah = $this->input->post('jumlah');

        $tv = 4200000;
        $kulkas = 2100000;
        $mesinCuci = 3800000;

        if ($barang == 'TV') {
            $hargaBarang = $tv;
        } elseif ($barang == 'Kulkas') {
            $hargaBarang = $kulkas;
        } elseif ($barang == 'Mesin Cuci') {
            $hargaBarang = $mesinCuci;
        }

        $totalHarga = intval($jumlah) * $hargaBarang;
        
        $data['belanja'] = [$customer, $barang, $jumlah, $totalHarga];


        $data['judul'] = 'Form Belanja';
        $data['title'] = 'Praktikum 2';
		$this->load->view('praktikum/praktikum_2/form_belanja.php', $data);

    }

}
?>