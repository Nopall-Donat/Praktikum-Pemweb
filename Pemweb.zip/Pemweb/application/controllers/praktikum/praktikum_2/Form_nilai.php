<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form_nilai extends CI_Controller {

    public function index() {
        $data['judul'] = 'Form Nilai';
        $data['title'] = 'Praktikum 2';
		$this->load->view('praktikum/praktikum_2/form_nilai.php', $data);

    }

}
?>