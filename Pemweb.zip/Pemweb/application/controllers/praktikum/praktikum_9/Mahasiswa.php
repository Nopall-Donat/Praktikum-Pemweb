<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Mahasiswa extends CI_Controller {

        public function index() {

            $data['judul'] = 'Tabel Mahasiswa';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Mahasiswa';
      
            $this->load->model('dbkampus/mahasiswa_model', 'mhs');
            $list_mhs = $this->mhs->getAll();
            $data['list_mhs'] = $list_mhs;

            $this->load->view('praktikum/praktikum_9/mahasiswa/index.php', $data);

        }

        public function view() {

            $data['judul'] = 'Data Lengkap Mahasiswa';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Mahasiswa';
            $data['view'] = 'View';
            
            $_nim = $this->input->get('id');
            $this->load->model('dbkampus/mahasiswa_model', 'data_mhs');
            $data['mhs'] = $this->data_mhs->findById($_nim);
            

            $this->load->view('praktikum/praktikum_9/mahasiswa/view.php', $data);

        }

        public function form() {

            $data['judul'] = 'Tambah Mahasiswa Baru';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Mahasiswa';
            $data['tambah'] = 'Tambah Mahasiswa';

            $this->load->view('praktikum/praktikum_9/mahasiswa/form.php', $data);

        }

        public function save() {
            
            $data['judul'] = 'Tambah Mahasiswa Baru';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Mahasiswa';
            $data['tambah'] = 'Tambah Mahasiswa';
    
            $this->load->model('dbkampus/mahasiswa_model', 'mhs');
    
            $nim = $this->input->post('nim');
            $nama = $this->input->post('nama');
            $gender = $this->input->post('jk');
            $tmp_lahir = $this->input->post('tmp_lahir');
            $tgl_lahir = $this->input->post('tgl_lahir');
            $prodi = $this->input->post('prodi');
            $ipk = $this->input->post('ipk');
            $idupdate = $this->input->post('idupdate');

            if (isset($idupdate)) {
                $data_mhs = [$nim, $nama, $gender, $tmp_lahir, $tgl_lahir, $ipk, $prodi, $idupdate];
                $this->mhs->update($data_mhs);
            } else {
                $data_mhs = [$nim, $nama, $gender, $tmp_lahir, $tgl_lahir, $ipk, $prodi];
                $this->mhs->save($data_mhs);
            }

            
            redirect(base_url("index.php").'/praktikum/praktikum_9/mahasiswa/view?id='.$nim, 'refresh');
        }

        public function update() {
            $data['judul'] = 'Data Lengkap Mahasiswa';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Mahasiswa';
            $data['view'] = 'Update';
            
            $_nim = $this->input->get('id');
            $this->load->model('dbkampus/mahasiswa_model', 'data_mhs');
            $data['mhs'] = $this->data_mhs->findById($_nim);
            

            $this->load->view('praktikum/praktikum_9/mahasiswa/update.php', $data);

        }

        public function delete() {

            $_nim = $this->input->get('id');
            $this->load->model('dbkampus/mahasiswa_model', 'data_mhs');
            $this->data_mhs->delete($_nim);

            redirect(base_url("index.php").'/praktikum/praktikum_9/mahasiswa/index', 'refresh');
        }
    }
?>