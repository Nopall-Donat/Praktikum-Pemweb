<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Dosen extends CI_Controller {

        public function index() {
            
            $data['judul'] = 'Tabel Dosen';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Dosen';
            
            $this->load->model('dbkampus/dosen_model', 'dsn');
            $list_dsn = $this->dsn->getAll();
            $data['list_dsn'] = $list_dsn;

            $this->load->view('praktikum/praktikum_9/dosen/index.php', $data);

        }

        public function view() {

            $data['judul'] = 'Data Lengkap Dosen';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Dosen';
            $data['view'] = 'View';
            
            $_nidn = $this->input->get('id');
            $this->load->model('dbkampus/dosen_model', 'data_dsn');
            $data['dsn'] = $this->data_dsn->findById($_nidn);
            

            $this->load->view('praktikum/praktikum_9/dosen/view.php', $data);

        }

        
        public function form() {

            $data['judul'] = 'Tambah Dosen Baru';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Dosen';
            $data['tambah'] = 'Tambah Dosen';

            $this->load->view('praktikum/praktikum_9/dosen/form.php', $data);

        }

        public function save() {
            
            $data['judul'] = 'Tambah Dosen Baru';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Dosen';
            $data['tambah'] = 'Tambah Dosen';
    
            $this->load->model('dbkampus/dosen_model', 'dsn');
    
            $nidn = $this->input->post('nidn');
            $nama = $this->input->post('nama');
            $gender = $this->input->post('jk');
            $tmp_lahir = $this->input->post('tmp_lahir');
            $tgl_lahir = $this->input->post('tgl_lahir');
            $prodi = $this->input->post('prodi');
            $pendidikan = $this->input->post('pendidikan');
            $idupdate = $this->input->post('idupdate');

            if (isset($idupdate)) {
                $data_dsn = [$nidn, $nama, $gender, $tmp_lahir, $tgl_lahir, $pendidikan, $prodi, $idupdate];
                $this->dsn->update($data_dsn);
            } else { 
                $data_dsn = [$nidn, $nama, $gender, $tmp_lahir, $tgl_lahir, $pendidikan, $prodi];
                $this->dsn->save($data_dsn);
            }

            
            redirect(base_url("index.php").'/praktikum/praktikum_9/dosen/view?id='.$nidn);
        }

        public function update() {
            $data['judul'] = 'Data Lengkap Dosen';
            $data['title'] = 'Praktikum 9';
            $data['table'] = 'Dosen';
            $data['view'] = 'Update';
            
            $_nidn = $this->input->get('id');
            $this->load->model('dbkampus/dosen_model', 'data_dsn');
            $data['dsn'] = $this->data_dsn->findById($_nidn);
            

            $this->load->view('praktikum/praktikum_9/dosen/update.php', $data);
        }

        public function delete() {
            $_nidn = $this->input->get('id');
            $this->load->model('dbkampus/dosen_model', 'data_dsn');
            $this->data_dsn->delete($_nidn);

            redirect(base_url("index.php").'/praktikum/praktikum_9/dosen/index', 'refresh');
        }

    }
?>