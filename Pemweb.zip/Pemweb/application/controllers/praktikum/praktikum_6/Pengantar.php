<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengantar extends CI_Controller {

    public function index() {
        $data['judul'] = 'Dashboard Praktikum 06';
        $data['title'] = 'Praktikum 6';
		$this->load->view('praktikum/praktikum_6/pengantar/index', $data);

    }

}
?>