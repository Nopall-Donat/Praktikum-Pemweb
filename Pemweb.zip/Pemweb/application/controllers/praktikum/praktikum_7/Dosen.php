<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

    public function form() {
        $data['judul'] = 'Form Kelola Dosen';
        $data['title'] = 'Praktikum 7';
        $data['table'] = 'Dosen';
		$this->load->view('praktikum/praktikum_7/dosen/form', $data);

    }

    public function view() {
        $data['judul'] = 'Table Kelola Dosen';
        $data['title'] = 'Praktikum 7';
        $data['table'] = 'Dosen';
        $this->load->model("model_kuliah/dosen_model", "dsn");

        $this->dsn->nidn = $this->input->post('nidn');
        $this->dsn->nama = $this->input->post('nama');
        $this->dsn->gender = $this->input->post('jk');
        $this->dsn->tmp_lahir = $this->input->post('tmp_lahir');
        $this->dsn->tgl_lahir = $this->input->post('tgl_lahir');
        $this->dsn->prodi = $this->input->post('prodi');
        $this->dsn->pendidikan = $this->input->post('pendidikan');

        $data['dsn'] = $this->dsn;

		$this->load->view('praktikum/praktikum_7/dosen/view', $data);

    }
}
?>