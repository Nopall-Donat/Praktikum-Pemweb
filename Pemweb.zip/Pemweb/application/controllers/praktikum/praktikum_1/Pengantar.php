<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengantar extends CI_Controller {

    public function index() {
        $data['judul'] = 'Dashboard Praktikum 01';
        $data['title'] = 'Praktikum 1';
		$this->load->view('praktikum/praktikum_1/pengantar/index', $data);

    }

}
?>