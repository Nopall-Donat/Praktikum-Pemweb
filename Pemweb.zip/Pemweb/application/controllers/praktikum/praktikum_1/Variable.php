<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Variable extends CI_Controller {

    public function info() {
        $data['judul'] = 'info.php';
        $data['title'] = 'Praktikum 1';
        $this->load->view('praktikum/praktikum_1/variable/info.php', $data);
    }

    public function variable_system() {
        $data['judul'] = 'Variable System';
        $data['title'] = 'Praktikum 1';
        $this->load->view('praktikum/praktikum_1/variable/variable_system.php', $data);
    }

    public function variable_user() {
        $data['judul'] = 'Variable User';
        $data['title'] = 'Praktikum 1';
        $this->load->view('praktikum/praktikum_1/variable/variable_user.php', $data);
    }

    public function variable_konstanta() {
        $data['judul'] = 'Variable Konstanta';
        $data['title'] = 'Praktikum 1';
        $this->load->view('praktikum/praktikum_1/variable/variable_konstanta.php', $data);
    }
}
?>