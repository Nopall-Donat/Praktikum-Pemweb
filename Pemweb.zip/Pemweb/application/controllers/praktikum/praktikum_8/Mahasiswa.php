<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Mahasiswa extends CI_Controller {

        public function index() {

            $data['judul'] = 'Tabel Mahasiswa';
            $data['title'] = 'Praktikum 8';
            $data['table'] = 'Mahasiswa';
            
            $this->load->model('dbkampus/mahasiswa_model', 'mhs');
            $list_mhs = $this->mhs->getAll();
            $data['list_mhs'] = $list_mhs;

            $this->load->view('praktikum/praktikum_8/mahasiswa/index.php', $data);

        }

        public function view() {

            $data['judul'] = 'Data Lengkap Mahasiswa';
            $data['title'] = 'Praktikum 8';
            $data['table'] = 'Mahasiswa';
            $data['view'] = 'View';
            
            $_nim = $this->input->get('id');
            $this->load->model('dbkampus/mahasiswa_model', 'data_mhs');
            $data['mhs'] = $this->data_mhs->findById($_nim);
            

            $this->load->view('praktikum/praktikum_8/mahasiswa/view.php', $data);

        }
    }
?>