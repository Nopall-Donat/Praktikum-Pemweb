<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Dosen extends CI_Controller {

        public function index() {
            
            $data['judul'] = 'Tabel Dosen';
            $data['title'] = 'Praktikum 8';
            $data['table'] = 'Dosen';

            
            $this->load->model('dbkampus/dosen_model', 'dsn');
            $list_dsn = $this->dsn->getAll();
            $data['list_dsn'] = $list_dsn;

            $this->load->view('praktikum/praktikum_8/dosen/index.php', $data);

        }

        public function view() {

            $data['judul'] = 'Data Lengkap Dosen';
            $data['title'] = 'Praktikum 8';
            $data['table'] = 'Dosen';
            $data['view'] = 'View';
            
            $_nidn = $this->input->get('id');
            $this->load->model('dbkampus/dosen_model', 'data_dsn');
            $data['dsn'] = $this->data_dsn->findById($_nidn);
            

            $this->load->view('praktikum/praktikum_8/dosen/view.php', $data);

        }
    }
?>