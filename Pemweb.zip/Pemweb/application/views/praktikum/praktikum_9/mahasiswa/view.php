<!-- Meta -->
<?php $this->load->view('layout/meta') ?>

<!-- Header / Navbar -->
<?php $this->load->view('layout/header') ?>

<!-- Main Sidebar -->
<?php $this->load->view('layout/sidebar') ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $title ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>/praktikum/praktikum_9/pengantar"><?=$title?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo base_url('index.php')?>/praktikum/praktikum_9/mahasiswa/index"><?=$table?></a></li>
                        <li class="breadcrumb-item active"><?=$view?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?= $judul ?></h3>

                            <div class="card-tools">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                    <input type="text" name="table_search" class="form-control float-right"
                                        placeholder="Search">

                                    <div class="input-group-append">
                                        <button type="submit" name="submit_search" class="btn btn-default">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-3">
                            <div class="row">
                                <div class="col-8">
                                    <table class="table table-striped text-nowrap">
                                        <tbody>
                                            <tr>
                                                <td>NIM</td>
                                                <td>:</td>
                                                <td><?= $mhs->nim ?></td>
                                            </tr>
                                            <tr>
                                                <td>Nama Lengkap</td>
                                                <td>:</td>
                                                <td><?= $mhs->nama ?></td>
                                            </tr>
                                            <tr>
                                                <td>Gender</td>
                                                <td>:</td>
                                                <td><?= $mhs->gender ?></td>
                                            </tr>
                                            <tr>
                                                <td>Tempat, Tanggal Lahir</td>
                                                <td>:</td>
                                                <td><?= $mhs->tmp_lahir ?>, <?= $mhs->tgl_lahir ?></td>
                                            </tr>
                                            <tr>
                                                <td>IPK</td>
                                                <td>:</td>
                                                <td><?= $mhs->ipk ?></td>
                                            </tr>
                                            <tr>
                                                <td>Prodi</td>
                                                <td>:</td>
                                                <td><?= $mhs->prodi_kode ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-4">

                                </div>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->



<!-- Footer -->
<?php $this->load->view('layout/footer') ?>

<!-- JS -->
<?php $this->load->view('layout/js') ?>