<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Belanja</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Times New Roman', Times, serif;
            height: 150vh;
        }

        header,
        footer {
            width: 100%;
            height: 50px;
            padding: 10px;
            background-color: rgb(211, 206, 206);
            border: 1px solid rgb(202, 201, 201);
        }

        .section {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h3 {
            width: 100%;
            height: 60px;
            border: 1px solid rgb(202, 201, 201);
            padding: 15px;
            font-size: x-large;
        }

        form {
            margin-top: 30px;
            margin-bottom: 20px;
        }

        .result {
            border-top: 1px solid rgb(202, 201, 201);
        }

        .font-result {
            font-size: larger;
            margin: 15px 0 0px 10px;
        }

        ul {
            text-decoration: dotted;
            margin: 0 0 20px 40px;
        }

        .created {
            text-align: center;
            margin: auto;
            font-size: small;
        }

        .text-center {
            text-align: center;
            margin: auto;
        }

        .form-section {
            display: flex;
            justify-content: space-between;
        }

        .form-belanja {
            margin-left: 20px;
        }

        .daftar-harga {
            margin-top: 20px;
            margin-right: 20px;
        }

        .harga-barang {
            width: 290px;
            border: 1px solid rgb(202, 201, 201);
            margin: 0;
            padding: 10px;
        }

        .ket {
            background-color: rgba(16, 16, 192, 0.856);
            color: white;
        }
    </style>
</head>

<body>
    <!-- Header -->
    <header>
        <h4 class="text-center">Toko Online</h4>
    </header>

    <h3>Belanja Online</h3>
    <!-- Form Section -->
    <div class="form-section">
        <!-- Form Belanja -->
        <form class="form-belanja" method="POST"
            action="<?php echo base_url("index.php")?>/praktikum/praktikum_2/form_belanja">
            <div class="form-group row">
                <label for="costumer" class="col-3 col-form-label">Costumer</label>
                <div class="col-9">
                    <input id="customer" name="customer" placeholder="Nama Customer" type="text" class="form-control"
                        required="required">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-3">Pilih Produk</label>
                <div class="col-9">
                    <div class="custom-control custom-radio custom-control-inline">
                        <input name="produk" id="produk_0" type="radio" aria-describedby="produkHelpBlock"
                            class="custom-control-input" value="TV" required="required">
                        <label for="produk_0" class="custom-control-label">TV</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input name="produk" id="produk_1" type="radio" aria-describedby="produkHelpBlock"
                            class="custom-control-input" value="Kulkas" required="required">
                        <label for="produk_1" class="custom-control-label">Kulkas</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input name="produk" id="produk_2" type="radio" aria-describedby="produkHelpBlock"
                            class="custom-control-input" value="Mesin Cuci" required="required">
                        <label for="produk_2" class="custom-control-label">Mesin Cuci</label>
                    </div>
                    <span id="produkHelpBlock" class="form-text text-muted">Pilih Produk yang akan dibeli</span>
                </div>
            </div>
            <div class="form-group row">
                <label for="jumlah" class="col-3 col-form-label">Jumlah</label>
                <div class="col-9">
                    <input id="jumlah" name="jumlah" placeholder="jumlah" type="number" class="form-control"
                        required="required">
                </div>
            </div>
            <div class="form-group row">
                <div class="offset-3 col-9">
                    <button name="proses" type="submit" value="Kirim" class="btn btn-success">Kirim</button>
                </div>
            </div>
        </form>

        <!-- Aside Daftar Harga -->
        <aside>
            <div class="daftar-harga">
                <p class="harga-barang ket">Daftar Harga</p>
                <p class="harga-barang">TV : Rp 4.200.000</p>
                <p class="harga-barang">Kulkas : Rp 2.100.000</p>
                <p class="harga-barang">Mesin Cuci : Rp 3.800.000</p>
                <p class="harga-barang ket">Harga dapat berubah setiap saat!</p>
            </div>
        </aside>
    </div>

    <!-- div result data -->
    <div>
        <div class="result">
            <p class="font-result">Result Data</p>
            <?php
                
                    if (isset($_POST['proses'])) {
                        echo '<ul>';
                        echo '<li>Nama Costumer : '. ucwords($belanja->customer). '</li>';
                        echo '<li>Produk Pilihan : '. $belanja->barang. '</li>';
                        echo '<li>Harga Barang: Rp '. number_format($belanja->hargaBarang,2,',','.'). '</li>';
                        echo '<li>Jumlah Beli : '. $belanja->jumlah . '</li>';
                        echo '<li>Total Harga : Rp '. number_format($belanja->totalHarga,2,',','.'). '</li>';
                        echo '</ul>';
                    } else {
                        echo '<p>Daftar Belum Diisi</p>';
                    }
                ?>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p class="created">Develop by @nopall_donat</p>
    </footer>
</body>

</html>