</head>
<?php
  if(!$this->session->has_userdata('USERNAME')) {
    redirect(base_url("index.php/user/login"));
  }

?>

<body class="hold-transition sidebar-mini layout-fixed">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="<?php echo base_url("index.php"); ?>" class="nav-link">Home</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="#" class="nav-link">Contact</a>
            </li>
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
            <!-- Navbar Search -->
            <li class="nav-item">
                <a class="nav-link" data-widget="navbar-search" href="#" role="button">
                    <i class="fas fa-search"></i>
                </a>
                <div class="navbar-search-block">
                    <form class="form-inline">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" type="search" placeholder="Search"
                                aria-label="Search">
                            <div class="input-group-append">
                                <button class="btn btn-navbar" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                    <i class="fas fa-expand-arrows-alt"></i>
                </a>
            </li>

            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle d-flex" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">      
                    <div class="image">
                        <img src="<?php echo base_url('dist/img/NopalProfile.png')?>" class="img-circle mb-1" style="width: 25px;"
                            alt="User Image">
                    </div>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo base_url("index.php"); ?>">Profile</a>
                    <a class="dropdown-item" href="#">Beranda</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-primary" href="<?php echo base_url("index.php/user/login/index"); ?>">Switch Account</a>
                    <a class="dropdown-item text-primary" href="<?php echo base_url("index.php/user/register/index"); ?>">Register</a>
                    <a class="dropdown-item" href="<?php echo base_url("index.php/user/logout"); ?>" 
                        onclick="if(!confirm('Apa Anda Yakin Ingin Logout?')) {return false}">
                            Logout
                    </a>
                </div>
            </li>
        </ul>
    </nav>
    <!-- /.navbar -->